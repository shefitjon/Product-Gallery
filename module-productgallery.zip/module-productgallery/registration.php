<?php
/**
 * 
 * @package Skianet_ProductGallery
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Skianet_ProductGallery',
    __DIR__
);
